<footer class="footer text-center">
    © {{date('Y')}} bagikanceritamu.com <span class="d-none d-sm-inline-block"> by Ditama Digital.</span>
</footer>